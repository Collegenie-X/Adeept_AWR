#!/usr/bin/python3
# File name   : setup.py
# Author      : Adeept
# Date        : 2020/3/14

import os
import time

curpath = os.path.realpath(__file__)
thisPath = "/" + os.path.dirname(curpath)

def replace_num(file,initial,new_num):  
    newline=""
    str_num=str(new_num)
    with open(file,"r") as f:
        for line in f.readlines():
            if(line.find(initial) == 0):
                line = (str_num+'\n')
            newline += line
    with open(file,"w") as f:
        f.writelines(newline)

def run_command(cmd=""):
    import subprocess
    p = subprocess.Popen(
        cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    result = p.stdout.read().decode('utf-8')
    status = p.poll()
    return status, result

def check_raspbain_version():
    _, result = run_command("cat /etc/debian_version|awk -F. '{print $1}'")
    return int(result.strip())

commands_apt = [
"sudo apt-get update",
"sudo apt-get install python3-gpiozero python3-pigpio",
"sudo apt-get install -y build-essential python3-dev libzmq3-dev",
"sudo apt-get purge -y wolfram-engine",
"sudo apt-get purge -y libreoffice*",
"sudo apt-get -y clean",
"sudo apt-get -y autoremove",
"sudo apt-get install -y i2c-tools",
"sudo apt-get install -y python3-smbus",
"sudo apt-get install -y python3-pyqt5 python3-opengl",
"sudo apt-get install -y python3-picamera2",
"sudo apt-get install -y python3-opencv",
"sudo apt-get install -y opencv-data",
"sudo apt-get install -y python3-pyaudio",
"sudo apt-get install -y libfreetype6-dev libjpeg-dev",
]
mark_apt = 0
for x in range(3):
    for command in commands_apt:
        if os.system(command) != 0:
            print("Error running installation step apt")
            mark_apt = 1
    if mark_apt == 0:
        break

commands_pip_1 = [
"sudo pip3 install adafruit-pca9685",
"sudo pip3 install mpu6050-raspberrypi",
"sudo pip3 install flask",
"sudo pip3 install flask_cors",
"sudo pip3 install numpy",
"sudo pip3 install pyzmq",
"sudo pip3 install imutils zmq pybase64 psutil",
"sudo pip3 install websockets==13.0",
"sudo pip3 install adafruit-circuitpython-ads7830",
"sudo -H pip3 install --upgrade luma.oled",
"sudo pip3 install rpi_ws281x",
]
commands_pip_2 = [
"sudo pip3 install adafruit-pca9685 --break-system-packages",
"sudo pip3 install mpu6050-raspberrypi --break-system-packages",
"sudo pip3 install flask --break-system-packages",
"sudo pip3 install flask_cors --break-system-packages",
"sudo pip3 install numpy --break-system-packages",
"sudo pip3 install pyzmq --break-system-packages",
"sudo pip3 install imutils zmq pybase64 psutil --break-system-packages",
"sudo pip3 install websockets==13.0 --break-system-packages",
"sudo pip3 install adafruit-circuitpython-ads7830 --break-system-packages",
"sudo -H pip3 install --upgrade luma.oled --break-system-packages",
"sudo pip3 install rpi_ws281x --break-system-packages",
]
mark_pip = 0
OS_version = check_raspbain_version()
if OS_version <= 11:
    for x in range(3):
        for command in commands_pip_1:
            if os.system(command) != 0:
                print("Error running installation step pip")
                mark_pip = 1
        if mark_pip == 0:
            break
else:
    for x in range(3):
        for command in commands_pip_2:
            if os.system(command) != 0:
                print("Error running installation step pip")
                mark_pip = 1
        if mark_pip == 0:
            break

commands_3 = [
    "cd ~",
    "sudo git clone https://github.com/oblique/create_ap",
    "cd create_ap && sudo make install",
    # "cd //home/pi/create_ap && sudo make install",
    "sudo apt-get install -y util-linux procps hostapd iproute2 iw haveged dnsmasq iptables iptables-persistent"
]

mark_3 = 0
for x in range(3):
    for command in commands_3:
        if os.system(command) != 0:
            print("Error running installation step 3")
            mark_2 = 1
    if mark_3 == 0:
        break

try:
	replace_num("/boot/config.txt",'#dtparam=i2c_arm=on','dtparam=i2c_arm=on\nstart_x=1\n')
except:
	print('try again')


try:
	os.system('sudo touch //home/pi/startup.sh')
	with open("//home/pi/startup.sh",'w') as file_to_write:
		#you can choose how to control the robot
		file_to_write.write("#!/bin/sh\nsudo python3 " + thisPath + "/server/webServer.py")
except:
	pass

os.system('sudo chmod 777 //home/pi/startup.sh')

replace_num('/etc/rc.local','fi','fi\n//home/pi/startup.sh start')

try: #fix conflict with onboard Raspberry Pi audio
	os.system('sudo touch /etc/modprobe.d/snd-blacklist.conf')
	with open("/etc/modprobe.d/snd-blacklist.conf",'w') as file_to_write:
		file_to_write.write("blacklist snd_bcm2835")
except:
	pass

print('The program in Raspberry Pi has been installed, disconnected and restarted. \nYou can now power off the Raspberry Pi to install the camera and driver board (Robot HAT). \nAfter turning on again, the Raspberry Pi will automatically run the program to set the servos port signal to turn the servos to the middle position, which is convenient for mechanical assembly.')
print('restarting...')
os.system("sudo reboot")
